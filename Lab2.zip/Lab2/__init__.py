# make `from HamBot import HamBot` work
from HamBot.src.robot_systems.robot import HamBot      # or from .src.robot_systems import HamBot
__all__ = ["HamBot"]